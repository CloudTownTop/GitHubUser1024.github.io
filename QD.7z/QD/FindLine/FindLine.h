#include<LNDZ.h>

int ll,l,m,r,rr,n;

void check(){
   ll=AR(4)<398;//390
   l=AR(2)<478;//370
   m=AR(1)<428;//420
   r=AR(3)<407;//400
   rr=AR(5)<328;//310
   n=ll+l+m+r+rr;
}

void findline(){
   if (ll==1) motor(-30,35);
   else if (l==1)  motor(0,35);
   else if (m==1)  motor(30,35);
   else if (r==1)  motor(30,0);
   else if (rr==1) motor(30,-35);
}

void cf(){
	check();findline();
}
